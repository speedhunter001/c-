int get_width(int x1, int x3);

int get_height(int y1, int y3);

int get_distance(int x1, int y1, int x2, int y2);
