#include <vector>
using namespace std;

vector<int> string_to_int(string points_str);


